<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cardgatedirectebanking}prestashop>cardgatedirectebanking_da9c72b9e543135f3f59e3c8ac68ef35'] = 'Betaal met';
$_MODULE['<{cardgatedirectebanking}prestashop>cardgatedirectebanking_bb17db56f4f028d0bc4b23687a394e5f'] = 'CardGate SofortBanking';
$_MODULE['<{cardgatedirectebanking}prestashop>cardgatedirectebanking_7e6359c51343f4ce5130029948767621'] = 'Accepteert betalingen met CardGate SofortBanking';
$_MODULE['<{cardgatedirectebanking}prestashop>cardgatedirectebanking_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Weet u zeker dat u uw details wilt verwijderen?';
$_MODULE['<{cardgatedirectebanking}prestashop>cardgatedirectebanking_59ca7aaff7f6bfd9dd776a6add44770f'] = 'De CardGate module is niet gevonden';
