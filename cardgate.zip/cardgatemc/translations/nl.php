<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cardgatemc}prestashop>cardgatemc_da9c72b9e543135f3f59e3c8ac68ef35'] = 'Betaal met';
$_MODULE['<{cardgatemc}prestashop>cardgatemc_14f93fb8eaa3c305a03ef9a702f28f3c'] = 'CardGate MisterCash';
$_MODULE['<{cardgatemc}prestashop>cardgatemc_6eb1b15b530fe056f500cfb16eeb8fb2'] = 'Accepteert betalingen met CardGate  MisterCash';
$_MODULE['<{cardgatemc}prestashop>cardgatemc_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Weet u zeker dat u uw details wilt verwijderen?';
$_MODULE['<{cardgatemc}prestashop>cardgatemc_59ca7aaff7f6bfd9dd776a6add44770f'] = 'De CardGate module is niet gevonden';
