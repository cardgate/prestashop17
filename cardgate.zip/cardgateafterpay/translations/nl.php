<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cardgateafterpay}prestashop>cardgateafterpay_da9c72b9e543135f3f59e3c8ac68ef35'] = 'Betaal met';
$_MODULE['<{cardgateafterpay}prestashop>cardgateafterpay_95f12add1b5427b22548ef7b4940b8c4'] = 'CardGate Afterpay';
$_MODULE['<{cardgateafterpay}prestashop>cardgateafterpay_6928882cdbec9291b50dd48d841412c4'] = 'Accepteert betalingen met CardGate  Afterpay';
$_MODULE['<{cardgateafterpay}prestashop>cardgateafterpay_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Weet u zeker dat u uw details wilt verwijderen?';
$_MODULE['<{cardgateafterpay}prestashop>cardgateafterpay_59ca7aaff7f6bfd9dd776a6add44770f'] = 'De CardGate module is niet gevonden';
