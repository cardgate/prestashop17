<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cardgatecreditcard}prestashop>cardgatecreditcard_da9c72b9e543135f3f59e3c8ac68ef35'] = 'Betaal met';
$_MODULE['<{cardgatecreditcard}prestashop>cardgatecreditcard_b9a7a46e250290a3efd31ce1d269107a'] = 'CardGate Creditcard';
$_MODULE['<{cardgatecreditcard}prestashop>cardgatecreditcard_590f4fe74d25d148b6097d67d5307e23'] = 'Accepteert betalingen met CardGate  Creditcard';
$_MODULE['<{cardgatecreditcard}prestashop>cardgatecreditcard_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Weet u zeker dat u uw details wilt verwijderen?';
$_MODULE['<{cardgatecreditcard}prestashop>cardgatecreditcard_59ca7aaff7f6bfd9dd776a6add44770f'] = 'De CardGate module is niet gevonden';
