<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cardgatesofortbanking}prestashop>cardgatesofortbanking_da9c72b9e543135f3f59e3c8ac68ef35'] = 'Betaal met';
$_MODULE['<{cardgatesofortbanking}prestashop>cardgatesofortbanking_3aaef313744284815ce102ae9610a638'] = 'CardGate SOFORT Banking';
$_MODULE['<{cardgatesofortbanking}prestashop>cardgatesofortbanking_d0c3a962baf71dc859573e83548eaa7a'] = 'Accepteert betalingen met CardGate SOFORT Banking.';
$_MODULE['<{cardgatesofortbanking}prestashop>cardgatesofortbanking_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Weet u zeker dat u uw details wilt verwijderen?';
$_MODULE['<{cardgatesofortbanking}prestashop>cardgatesofortbanking_a02758d758e8bec77a33d7f392eb3f8a'] = 'Er is geen valuta ingesteld voor deze module';
$_MODULE['<{cardgatesofortbanking}prestashop>cardgatesofortbanking_59ca7aaff7f6bfd9dd776a6add44770f'] = 'De CardGate module is niet gevonden';
