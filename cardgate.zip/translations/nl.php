<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cardgate}prestashop>cardgate_3a38a0ea09ba7f74d38d8194048cdff5'] = 'CardGate Bank algemeen';
$_MODULE['<{cardgate}prestashop>cardgate_a46f392bfe2071ea4abeadb8e304fc1b'] = 'CardGate Bank basis module';
$_MODULE['<{cardgate}prestashop>cardgate_5498f6bca4d4250efbdc119afdfdb2d2'] = 'Weet u zeker dat u de CardGate module wilt de-installeren?';
$_MODULE['<{cardgate}prestashop>cardgate_c888438d14855d7d96a2724ee9c306bd'] = 'Instellingen ge-update';
$_MODULE['<{cardgate}prestashop>cardgate_0956be666241fbaae79cb5675db123bd'] = 'Extra kosten voor';
$_MODULE['<{cardgate}prestashop>cardgate_d87816fa0d3d5e233fe4564f77515909'] = 'Voeg extra kosten toe voor de betaalmethode, bijvoorbeeld: 1.95 of 5%';
$_MODULE['<{cardgate}prestashop>cardgate_52f4393e1b52ba63e27310ca92ba098c'] = 'Algemene instellingen';
$_MODULE['<{cardgate}prestashop>cardgate_650be61892bf690026089544abbd9d26'] = 'Mode';
$_MODULE['<{cardgate}prestashop>cardgate_305fe996f5b22c6230470bcfabe112ad'] = 'Site Id';
$_MODULE['<{cardgate}prestashop>cardgate_2e09700574590df4ca7dcefee17e2be1'] = 'De Cardgate Site Id die u in uw Cardgate back-office kunt vinden';
$_MODULE['<{cardgate}prestashop>cardgate_b5d88c101908ee4325f2808e8a5504cf'] = 'Codeersleutel';
$_MODULE['<{cardgate}prestashop>cardgate_acf86e2e4d126dfd0f6f8f5d64111b30'] = 'De CardGate codeersleutel, die u in uw CardGate back-office kunt vinden';
$_MODULE['<{cardgate}prestashop>cardgate_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{cardgate}prestashop>cardgate_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar lijst';
$_MODULE['<{cardgate}prestashop>cardgatepayment_da9c72b9e543135f3f59e3c8ac68ef35'] = 'Betaal met';
$_MODULE['<{cardgate}prestashop>cardgatepayment_c888438d14855d7d96a2724ee9c306bd'] = 'Instellingen aangepast';
