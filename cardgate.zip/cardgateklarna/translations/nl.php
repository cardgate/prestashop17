<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cardgateklarna}prestashop>cardgateklarna_da9c72b9e543135f3f59e3c8ac68ef35'] = 'Betaal met';
$_MODULE['<{cardgateklarna}prestashop>cardgateklarna_312db65024f5d71d824d4220702f6ceb'] = 'CardGate Klarna';
$_MODULE['<{cardgateklarna}prestashop>cardgateklarna_52a592b45cbc238b4535dcf4b516c09b'] = 'Accepteert betalingen met CardGate Klarna';
$_MODULE['<{cardgateklarna}prestashop>cardgateklarna_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Weet u zeker dat u uw details wilt verwijderen?';
$_MODULE['<{cardgateklarna}prestashop>cardgateklarna_59ca7aaff7f6bfd9dd776a6add44770f'] = 'De CardGate module is niet gevonden';
