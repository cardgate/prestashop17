<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cardgatebancontact}prestashop>cardgatebancontact_da9c72b9e543135f3f59e3c8ac68ef35'] = 'Betaal met';
$_MODULE['<{cardgatebancontact}prestashop>cardgatebancontact_342b073f73e9dd5e0fc64cb278ab8a0e'] = 'CardGate Bankcontact';
$_MODULE['<{cardgatebancontact}prestashop>cardgatebancontact_5a090d4b78909a814c6ff7e957ebca40'] = 'Accepteert betalingen met CardGate Bancontact';
$_MODULE['<{cardgatebancontact}prestashop>cardgatebancontact_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Weet u zeker dat u uw details wilt verwijderen?';
$_MODULE['<{cardgatebancontact}prestashop>cardgatebancontact_a02758d758e8bec77a33d7f392eb3f8a'] = 'Er is geen valuta ingesteld voor deze module';
$_MODULE['<{cardgatebancontact}prestashop>cardgatebancontact_59ca7aaff7f6bfd9dd776a6add44770f'] = 'De CardGate module is niet gevonden';
